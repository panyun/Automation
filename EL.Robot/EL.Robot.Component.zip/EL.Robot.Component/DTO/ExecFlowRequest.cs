﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EL.Robot.Component.DTO
{
    public class ExecFlowRequest : CommponetRequest
    {
        public Flow Flow { get; set; }
    }
}
